MS2-Parser
==========

A Perl Parser for MS2 files, commonly used for mass spectrometry based proteomcis.
